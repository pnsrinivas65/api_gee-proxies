var response = context.getVariable("response.content");
var responseJson = JSON.parse(response);
var recommendations = context.getVariable("recommendations-output");
var recommendationsJson = JSON.parse(recommendations);

var products = responseJson["products"];
if (recommendationsJson["productIds"] && recommendationsJson["productIds"].length > 0) {
        for (var i = 0; i < products.length; i++) {
                var product = products[i];
                if (recommendationsJson["productIds"].indexOf(product["id"]) >= 0) {
                        product["featured"] = true;

                }
        }
}
responseJson["recommendations"] = recommendationsJson;

context.setVariable("response.content", JSON.stringify(responseJson));